# sml-audit

Conformance auditor for **S—ML Web** delivery profiles.

> One URL. Three weights. No separate internet.

Grades any URL against the S (Sparse), M (Medium), and L (Luxe) profile budgets from the S—ML Web paper. Zero dependencies, single file, Node ≥ 18.

## Install

```bash
# run directly
node sml-audit.js <url>

# or install the `sml-audit` command globally
npm link
sml-audit <url>
```

## Usage

```bash
sml-audit https://example.com/article/123
sml-audit https://example.com --profile=s     # grade one profile only
sml-audit https://example.com --json          # machine-readable output
sml-audit https://example.com --no-color
sml-audit https://example.com --max-fetch=25  # cap on render-blocking subresource fetches (default 15)
```

Exit codes: `0` pass, `1` one or more graded profiles fail, `2` error — so it drops straight into CI:

```yaml
- name: S—ML audit
  run: node sml-audit.js https://example.com --profile=s
```

## Example output

```
S—ML Audit: https://example.com/weather-alert
HTML 0.4 KB + 5 render-blocking resource(s) → initial payload 554 KB
~3 round trip(s) · 3 external / 3 blocking script(s) · 2 stylesheet(s) · fonts: yes

S — Sparse    FAIL
  ✗ Initial payload 554 KB exceeds budget 50 KB
  ✗ Core content unavailable without JavaScript (empty application shell)
  ✗ 2 third-party script host(s), budget: none

M — Medium   PASS
L — Luxe     PASS
```

## What it checks

| Check | S | M | L |
|---|---|---|---|
| Initial payload (HTML + render-blocking CSS/JS) | ≤ 50 KB | ≤ 500 KB | open |
| Core content without JavaScript | required | recommended | optional |
| Third-party script hosts | none | ≤ 5 | open |
| Custom fonts | avoid | ok | ok |
| Estimated round trips | ≤ 2 | ≤ 5 | open |
| Machine-readable summary (meta description / JSON-LD) | required | recommended | recommended |
| End-to-end TLS (localhost counts as secure) | required | required | required |

It also reports **profile discovery**: `Content-Profile` / `Available-Profiles` response headers, or `<link rel="alternate" data-profile="…">` tags.

## Caveats (0.1 prototype)

Static analysis only — no headless browser. It measures what crosses the wire, not what renders. "JS required" is a heuristic (empty app-root shell, or almost no visible text plus external scripts). Round trips are a coarse estimate. Budget thresholds are the paper's proposed starting points; edit `BUDGETS` at the top of `sml-audit.js` to experiment.

## License

MIT
